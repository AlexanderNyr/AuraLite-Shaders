#version 460 compatibility
// AuraLite Shaders - Copyright (c) 2026 AlexanderNyr. Licensed under CC BY-NC-SA 4.0.

// ==============================================================================
// AuraLite Shader Pack - Final Post-Processing Pass Fragment Shader (GLSL 460)
// ==============================================================================
// [v0.2.9] SSR moved here from composite.fsh so it operates on the fully lit
//   scene in colortex0. Normals and reflectivity are read from colortex6.

#define VIGNETTE // [true false]
#define EXPOSURE 2 // [1 2 3]
#define COLOR_SATURATION 2 // [1 2 3 4]
#define CONTRAST 2 // [1 2 3]
//#define SSR // [true false]
#define SSR_QUALITY 2 // [1 2 3]
#define SSR_STRENGTH 2 // [1 2 3]

in vec2 texcoord;

uniform sampler2D colortex0; // Fully lit scene from composite
uniform sampler2D colortex6; // Normals (rgb) + reflectivity (a) from composite
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;

layout(location = 0) out vec4 fragColor;

// ACES Filmic Tonemapping
vec3 ACESFilm(vec3 x) {
    float a = 2.51; float b = 0.03; float c = 2.43; float d = 0.59; float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Custom Vibrant Saturation controller
vec3 applyVibrancy(vec3 color, float amount) {
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    return clamp(mix(color, vec3(luma), amount), 0.0, 1.0);
}

// Helpers for coordinate transforms
vec3 screenToNDC(vec3 screen) { return 2.0 * screen - 1.0; }
vec3 ndcToScreen(vec3 ndc) { return 0.5 * ndc + 0.5; }

vec3 screenToView(vec2 uv, float depth) {
    vec4 ndc = vec4(screenToNDC(vec3(uv, depth)), 1.0);
    vec4 view = gbufferProjectionInverse * ndc;
    return view.xyz / view.w;
}

vec3 viewToScreen(vec3 view) {
    vec4 clip = gbufferProjection * vec4(view, 1.0);
    return ndcToScreen(clip.xyz / clip.w);
}

// Edge vignette for SSR — fades reflections near screen borders
float ssrEdgeFade(vec2 uv) {
    vec2 edge = smoothstep(vec2(0.0), vec2(0.035), uv) *
                (1.0 - smoothstep(vec2(0.965), vec2(1.0), uv));
    return edge.x * edge.y;
}

// ==============================================================================
// SSR — Screen-Space Reflections with adaptive step size
// ==============================================================================
// Runs in final.fsh so colortex0 contains the fully composited, lit scene.
// Uses adaptive marching: steps grow proportionally to the depth difference,
// covering large distances quickly while refining near intersections.
// Binary search narrows the hit point for sub-pixel accuracy.
// ==============================================================================
#ifdef SSR
vec4 traceSSR(vec3 viewPos, vec3 reflDir) {
    int maxSteps = 16;
    int binarySteps = 4;
    float stepScale = 1.4;
    #if SSR_QUALITY == 1
    maxSteps = 10;
    binarySteps = 3;
    stepScale = 1.6;
    #elif SSR_QUALITY == 3
    maxSteps = 32;
    binarySteps = 6;
    stepScale = 1.2;
    #endif

    // Reject rays pointing toward the camera (they cannot hit visible geometry)
    if (reflDir.z >= -0.05) return vec4(0.0);

    float invReflZ = 1.0 / abs(reflDir.z);
    float invFar = 1.0 / (2.0 * far);
    float rayLen = 1.0;
    vec3 prevPos = viewPos;

    for (int i = 0; i < 32; ++i) {
        if (i >= maxSteps) break;

        vec3 curPos = viewPos + reflDir * rayLen;
        vec3 curScreen = viewToScreen(curPos);

        // Out of screen — stop
        if (curScreen.x < 0.0 || curScreen.x > 1.0 ||
            curScreen.y < 0.0 || curScreen.y > 1.0) break;

        float sceneDepth = texture(depthtex0, curScreen.xy).r;
        float sceneZ = screenToView(curScreen.xy, sceneDepth).z;

        // Adaptive epsilon: larger for distant fragments and grazing angles
        float distEps = clamp(abs(sceneZ) * invFar, 0.0, 1.0);
        float epsilon = 1.0 + 0.1 * distEps;
        float diffZ = curPos.z - sceneZ * epsilon;

        if (diffZ < 0.0) {
            // Potential hit — refine with binary search
            vec3 a = prevPos;
            vec3 b = curPos;

            if (diffZ > -16.0) {
                for (int j = 0; j < 6; ++j) {
                    if (j >= binarySteps) break;
                    vec3 mid = (a + b) * 0.5;
                    vec3 midScreen = viewToScreen(mid);
                    float midSceneDepth = texture(depthtex0, midScreen.xy).r;
                    float midSceneZ = screenToView(midScreen.xy, midSceneDepth).z;
                    if (-mid.z < -midSceneZ) { a = mid; }
                    else                     { b = mid; }
                }
            }

            vec3 hitScreen = viewToScreen((a + b) * 0.5);

            // Validate hit
            if (hitScreen.x < 0.002 || hitScreen.x > 0.998 ||
                hitScreen.y < 0.002 || hitScreen.y > 0.998) break;

            float hitDepth = texture(depthtex0, hitScreen.xy).r;
            if (hitDepth >= 1.0) break; // sky

            vec3 hitColor = texture(colortex0, hitScreen.xy).rgb;
            float fresnel = 1.0 - dot(normalize(-viewPos), normalize(curPos - viewPos) * -1.0 + normalize(-viewPos));
            fresnel = clamp(fresnel, 0.1, 1.0);

            return vec4(hitColor, ssrEdgeFade(hitScreen.xy) * fresnel);
        }

        prevPos = curPos;
        // Adaptive step: jump proportionally to how far we are from the scene surface
        rayLen += max(stepScale * abs(diffZ) * invReflZ, 1.0);
    }

    return vec4(0.0);
}
#endif

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;

    // ==============================================================================
    // SSR — apply reflections on water, wet surfaces, metals
    // ==============================================================================
    #ifdef SSR
    {
        vec4 reflData = texture(colortex6, texcoord);
        float reflectivity = reflData.a;

        if (reflectivity > 0.01) {
            float depth = texture(depthtex0, texcoord).r;
            vec3 normal = normalize(reflData.rgb * 2.0 - 1.0);
            vec3 viewPos = screenToView(texcoord, depth);
            vec3 V = normalize(viewPos);
            vec3 R = normalize(reflect(V, normal));

            vec4 refl = traceSSR(viewPos, R);

            float ssrMult = 0.65;
            #if SSR_STRENGTH == 1
            ssrMult = 0.38;
            #elif SSR_STRENGTH == 3
            ssrMult = 0.88;
            #endif

            color = mix(color, refl.rgb, refl.a * reflectivity * ssrMult);
        }
    }
    #endif

    // 1. Calibrated exposure levels
    float expFactor = 1.0;
    #if EXPOSURE == 1
    expFactor = 0.75;
    #elif EXPOSURE == 3
    expFactor = 1.35;
    #endif
    color *= expFactor;

    // 2. Contrast Modes
    #if CONTRAST == 1
    color = clamp(mix(color, ACESFilm(color), 0.45), 0.0, 1.0);
    #elif CONTRAST == 2
    color = ACESFilm(color);
    #elif CONTRAST == 3
    color = ACESFilm(color);
    color = clamp(pow(color, vec3(1.12)), 0.0, 1.0);
    #endif

    // 3. Gamma correction (linear -> sRGB)
    color = pow(color, vec3(1.0 / 2.2));

    // 4. Vignette
    #ifdef VIGNETTE
    vec2 uv = texcoord - 0.5;
    float vignette = 1.0 - dot(uv, uv) * 0.38;
    color *= clamp(vignette, 0.0, 1.0);
    #endif

    // 5. Custom Color Saturation Level
    float vibAmount = -0.06;
    #if COLOR_SATURATION == 1
    vibAmount = 0.15;
    #elif COLOR_SATURATION == 3
    vibAmount = -0.16;
    #elif COLOR_SATURATION == 4
    vibAmount = -0.28;
    #endif
    color = applyVibrancy(color, vibAmount);

    fragColor = vec4(color, 1.0);
}
